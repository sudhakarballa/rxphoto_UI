package com.example.rxphoto;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
